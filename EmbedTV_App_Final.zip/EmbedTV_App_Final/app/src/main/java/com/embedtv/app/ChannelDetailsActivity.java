package com.embedtv.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class ChannelDetailsActivity extends AppCompatActivity {

    private static final String EXTRA_CHANNEL = "extra_channel";
    
    private ImageView ivChannelLogo;
    private TextView tvChannelName;
    private TextView tvChannelCategory;
    private Button btnPlay;
    private Button btnFavorite;
    private RecyclerView recyclerViewRelated;
    private Channel channel;
    private List<Channel> relatedChannels;

    public static void start(Context context, Channel channel) {
        Intent intent = new Intent(context, ChannelDetailsActivity.class);
        intent.putExtra(EXTRA_CHANNEL, new Gson().toJson(channel));
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_channel_details);

        // Inicializar views
        ivChannelLogo = findViewById(R.id.ivChannelLogo);
        tvChannelName = findViewById(R.id.tvChannelName);
        tvChannelCategory = findViewById(R.id.tvChannelCategory);
        btnPlay = findViewById(R.id.btnPlay);
        btnFavorite = findViewById(R.id.btnFavorite);
        recyclerViewRelated = findViewById(R.id.recyclerViewRelated);

        // Obter dados do canal
        String channelJson = getIntent().getStringExtra(EXTRA_CHANNEL);
        channel = new Gson().fromJson(channelJson, Channel.class);

        // Configurar views com dados do canal
        setupViews();
        
        // Carregar canais relacionados
        loadRelatedChannels();
        
        // Configurar RecyclerView para canais relacionados
        setupRelatedChannelsRecyclerView();
    }

    private void setupViews() {
        tvChannelName.setText(channel.getName());
        tvChannelCategory.setText(channel.getCategory());
        
        // Carregar logo do canal
        Glide.with(this)
                .load("file:///android_asset/logos/" + channel.getLogo())
                .placeholder(R.drawable.placeholder_channel)
                .error(R.drawable.error_channel)
                .into(ivChannelLogo);
        
        // Configurar botão de reprodução
        btnPlay.setOnClickListener(v -> {
            // Iniciar reprodução do canal
            PlayerActivity.start(this, channel);
        });
        
        // Configurar botão de favorito
        updateFavoriteButton();
        btnFavorite.setOnClickListener(v -> {
            // Alternar status de favorito
            channel.setFavorite(!channel.isFavorite());
            
            // Atualizar preferências
            FavoritesManager.toggleFavorite(this, channel);
            
            // Atualizar UI
            updateFavoriteButton();
            
            // Mostrar mensagem
            String message = channel.isFavorite() 
                    ? "Canal adicionado aos favoritos" 
                    : "Canal removido dos favoritos";
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        });
    }
    
    private void updateFavoriteButton() {
        // Verificar se o canal está nos favoritos
        boolean isFavorite = FavoritesManager.isFavorite(this, channel.getId());
        channel.setFavorite(isFavorite);
        
        // Atualizar texto e ícone do botão
        if (isFavorite) {
            btnFavorite.setText("Remover dos Favoritos");
            btnFavorite.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_favorite, 0, 0, 0);
        } else {
            btnFavorite.setText("Adicionar aos Favoritos");
            btnFavorite.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_favorite_border, 0, 0, 0);
        }
    }

    private void loadRelatedChannels() {
        // Aqui você carregaria canais relacionados da mesma categoria
        // Para simplificar, vamos apenas simular isso
        relatedChannels = new ArrayList<>();
        
        // Em um app real, você buscaria isso do seu repositório de dados
        // Exemplo: relatedChannels = channelRepository.getRelatedChannels(channel.getCategory(), channel.getId());
    }

    private void setupRelatedChannelsRecyclerView() {
        recyclerViewRelated.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        
        ChannelAdapter adapter = new ChannelAdapter(relatedChannels, relatedChannel -> {
            // Quando um canal relacionado for clicado, abrir seus detalhes
            ChannelDetailsActivity.start(this, relatedChannel);
            finish(); // Fechar a tela atual para evitar empilhamento
        });
        
        recyclerViewRelated.setAdapter(adapter);
    }
}
