package com.embedtv.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FavoritesManager {
    private static final String PREF_FAVORITES = "favorites_channels";

    public static boolean isFavorite(Context context, String channelId) {
        Set<String> favorites = getFavoriteIds(context);
        return favorites.contains(channelId);
    }

    public static void toggleFavorite(Context context, Channel channel) {
        Set<String> favorites = getFavoriteIds(context);
        
        if (favorites.contains(channel.getId())) {
            // Remover dos favoritos
            favorites.remove(channel.getId());
        } else {
            // Adicionar aos favoritos
            favorites.add(channel.getId());
        }
        
        // Salvar alterações
        saveFavoriteIds(context, favorites);
    }

    public static List<Channel> getFavoriteChannels(Context context, List<Channel> allChannels) {
        Set<String> favoriteIds = getFavoriteIds(context);
        List<Channel> favoriteChannels = new ArrayList<>();
        
        for (Channel channel : allChannels) {
            if (favoriteIds.contains(channel.getId())) {
                channel.setFavorite(true);
                favoriteChannels.add(channel);
            }
        }
        
        return favoriteChannels;
    }

    private static Set<String> getFavoriteIds(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getStringSet(PREF_FAVORITES, new HashSet<>());
    }

    private static void saveFavoriteIds(Context context, Set<String> favoriteIds) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putStringSet(PREF_FAVORITES, favoriteIds);
        editor.apply();
    }
}
