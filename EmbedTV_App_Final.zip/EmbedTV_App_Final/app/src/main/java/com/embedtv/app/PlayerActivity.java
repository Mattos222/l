package com.embedtv.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

public class PlayerActivity extends AppCompatActivity {

    private static final String EXTRA_CHANNEL = "extra_channel";
    
    private WebView webView;
    private ProgressBar progressBar;
    private ImageButton btnFullscreen;
    private ImageButton btnBack;
    private Channel channel;

    public static void start(Context context, Channel channel) {
        Intent intent = new Intent(context, PlayerActivity.class);
        intent.putExtra(EXTRA_CHANNEL, new Gson().toJson(channel));
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        // Inicializar views
        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        btnFullscreen = findViewById(R.id.btnFullscreen);
        btnBack = findViewById(R.id.btnBack);

        // Obter dados do canal
        String channelJson = getIntent().getStringExtra(EXTRA_CHANNEL);
        channel = new Gson().fromJson(channelJson, Channel.class);

        // Configurar WebView
        setupWebView();
        
        // Configurar botões
        setupButtons();
        
        // Carregar o conteúdo embed
        loadEmbedContent();
    }

    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        
        // Configurar WebViewClient para lidar com navegação dentro do WebView
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
            
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
            }
        });
        
        // Configurar WebChromeClient para lidar com eventos de mídia
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                progressBar.setProgress(newProgress);
            }
        });
    }
    
    private void setupButtons() {
        btnBack.setOnClickListener(v -> finish());
        
        btnFullscreen.setOnClickListener(v -> {
            // Implementar lógica de tela cheia
            Toast.makeText(PlayerActivity.this, "Alternando modo tela cheia", Toast.LENGTH_SHORT).show();
            toggleFullscreen();
        });
    }
    
    private void toggleFullscreen() {
        // Implementar lógica para alternar entre modo normal e tela cheia
        View decorView = getWindow().getDecorView();
        int uiOptions;
        
        if ((decorView.getSystemUiVisibility() & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
            // Entrar em modo tela cheia
            uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN | 
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen_exit);
        } else {
            // Sair do modo tela cheia
            uiOptions = View.SYSTEM_UI_FLAG_VISIBLE;
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen);
        }
        
        decorView.setSystemUiVisibility(uiOptions);
    }

    private void loadEmbedContent() {
        progressBar.setVisibility(View.VISIBLE);
        
        // Carregar a URL do embed no WebView
        webView.loadUrl(channel.getEmbedUrl());
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Pausar o WebView para economizar recursos
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Retomar o WebView
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        // Limpar o WebView
        webView.destroy();
        super.onDestroy();
    }
}
