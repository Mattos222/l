package com.embedtv.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

public class CategoryChannelsFragment extends Fragment {

    private static final String ARG_CATEGORY_NAME = "category_name";
    private static final String ARG_CHANNELS = "channels";

    private String categoryName;
    private List<Channel> channels;
    private RecyclerView recyclerViewChannels;
    private TextView tvCategoryTitle;

    public static CategoryChannelsFragment newInstance(String categoryName, List<Channel> channels) {
        CategoryChannelsFragment fragment = new CategoryChannelsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_CATEGORY_NAME, categoryName);
        args.putString(ARG_CHANNELS, new Gson().toJson(channels));
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            categoryName = getArguments().getString(ARG_CATEGORY_NAME);
            String channelsJson = getArguments().getString(ARG_CHANNELS);
            channels = new Gson().fromJson(channelsJson, new TypeToken<ArrayList<Channel>>(){}.getType());
        } else {
            channels = new ArrayList<>();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category_channels, container, false);
        
        // Inicializar views
        recyclerViewChannels = view.findViewById(R.id.recyclerViewChannels);
        tvCategoryTitle = view.findViewById(R.id.tvCategoryTitle);
        
        // Configurar título da categoria
        tvCategoryTitle.setText(categoryName);
        
        // Configurar RecyclerView
        setupRecyclerView();
        
        return view;
    }

    private void setupRecyclerView() {
        // Usar GridLayoutManager para exibir canais em grade
        recyclerViewChannels.setLayoutManager(new GridLayoutManager(getContext(), 3));
        
        // Criar adapter para canais
        ChannelAdapter adapter = new ChannelAdapter(channels, channel -> {
            // Quando um canal for clicado, abrir seus detalhes
            ChannelDetailsActivity.start(getContext(), channel);
        });
        
        recyclerViewChannels.setAdapter(adapter);
    }
}
