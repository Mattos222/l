package com.embedtv.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class FavoritesFragment extends Fragment {

    private RecyclerView recyclerViewFavorites;
    private TextView tvEmptyFavorites;
    private List<Channel> allChannels;
    private List<Channel> favoriteChannels;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorites, container, false);
        
        // Inicializar views
        recyclerViewFavorites = view.findViewById(R.id.recyclerViewFavorites);
        tvEmptyFavorites = view.findViewById(R.id.tvEmptyFavorites);
        
        // Carregar todos os canais
        loadAllChannels();
        
        // Carregar canais favoritos
        loadFavoriteChannels();
        
        // Configurar RecyclerView
        setupRecyclerView();
        
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Recarregar favoritos quando o fragmento se tornar visível novamente
        loadFavoriteChannels();
        setupRecyclerView();
    }

    private void loadAllChannels() {
        try {
            // Carregar arquivo JSON de canais dos assets
            String jsonString = loadJSONFromAsset("channels.json");
            Gson gson = new Gson();
            Type channelListType = new TypeToken<ArrayList<Channel>>(){}.getType();
            allChannels = gson.fromJson(jsonString, channelListType);
        } catch (Exception e) {
            e.printStackTrace();
            allChannels = new ArrayList<>();
        }
    }

    private String loadJSONFromAsset(String fileName) {
        String json;
        try {
            InputStream is = getActivity().getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    private void loadFavoriteChannels() {
        // Obter canais favoritos usando o FavoritesManager
        favoriteChannels = FavoritesManager.getFavoriteChannels(getContext(), allChannels);
    }

    private void setupRecyclerView() {
        // Usar GridLayoutManager para exibir favoritos em grade
        recyclerViewFavorites.setLayoutManager(new GridLayoutManager(getContext(), 3));
        
        // Verificar se há favoritos
        if (favoriteChannels.isEmpty()) {
            recyclerViewFavorites.setVisibility(View.GONE);
            tvEmptyFavorites.setVisibility(View.VISIBLE);
        } else {
            recyclerViewFavorites.setVisibility(View.VISIBLE);
            tvEmptyFavorites.setVisibility(View.GONE);
            
            // Criar adapter para favoritos
            ChannelAdapter adapter = new ChannelAdapter(favoriteChannels, channel -> {
                // Quando um canal for clicado, abrir seus detalhes
                ChannelDetailsActivity.start(getContext(), channel);
            });
            
            recyclerViewFavorites.setAdapter(adapter);
        }
    }
}
