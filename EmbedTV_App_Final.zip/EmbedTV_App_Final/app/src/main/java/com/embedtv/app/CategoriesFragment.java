package com.embedtv.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class CategoriesFragment extends Fragment {

    private RecyclerView recyclerViewCategories;
    private List<String> categories;
    private List<Channel> allChannels;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_categories, container, false);
        
        // Inicializar views
        recyclerViewCategories = view.findViewById(R.id.recyclerViewCategories);
        
        // Carregar todos os canais
        loadAllChannels();
        
        // Extrair categorias únicas
        extractCategories();
        
        // Configurar RecyclerView
        setupRecyclerView();
        
        return view;
    }

    private void loadAllChannels() {
        try {
            // Carregar arquivo JSON de canais dos assets
            String jsonString = loadJSONFromAsset("channels.json");
            Gson gson = new Gson();
            Type channelListType = new TypeToken<ArrayList<Channel>>(){}.getType();
            allChannels = gson.fromJson(jsonString, channelListType);
        } catch (Exception e) {
            e.printStackTrace();
            allChannels = new ArrayList<>();
        }
    }

    private String loadJSONFromAsset(String fileName) {
        String json;
        try {
            InputStream is = getActivity().getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    private void extractCategories() {
        categories = new ArrayList<>();
        
        // Usar um conjunto para evitar duplicatas
        for (Channel channel : allChannels) {
            String category = channel.getCategory();
            if (!categories.contains(category)) {
                categories.add(category);
            }
        }
    }

    private void setupRecyclerView() {
        // Usar GridLayoutManager para exibir categorias em grade
        recyclerViewCategories.setLayoutManager(new GridLayoutManager(getContext(), 2));
        
        // Criar adapter para categorias
        CategoryGridAdapter adapter = new CategoryGridAdapter(categories, categoryName -> {
            // Quando uma categoria for clicada, mostrar todos os canais dessa categoria
            showChannelsInCategory(categoryName);
        });
        
        recyclerViewCategories.setAdapter(adapter);
    }

    private void showChannelsInCategory(String categoryName) {
        // Filtrar canais da categoria selecionada
        List<Channel> categoryChannels = new ArrayList<>();
        for (Channel channel : allChannels) {
            if (channel.getCategory().equals(categoryName)) {
                categoryChannels.add(channel);
            }
        }
        
        // Abrir um novo fragmento ou atividade para mostrar os canais
        CategoryChannelsFragment fragment = CategoryChannelsFragment.newInstance(categoryName, categoryChannels);
        
        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit();
    }
}
