package com.embedtv.app;

import java.util.List;

public class CategoryWithChannels {
    private String categoryName;
    private List<Channel> channels;

    public CategoryWithChannels(String categoryName, List<Channel> channels) {
        this.categoryName = categoryName;
        this.channels = channels;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public List<Channel> getChannels() {
        return channels;
    }
}
