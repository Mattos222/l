package com.embedtv.app;

public class Channel {
    private String id;
    private String name;
    private String embedUrl;
    private String category;
    private String logo;
    private boolean isFavorite;

    public Channel(String id, String name, String embedUrl, String category, String logo) {
        this.id = id;
        this.name = name;
        this.embedUrl = embedUrl;
        this.category = category;
        this.logo = logo;
        this.isFavorite = false;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmbedUrl() {
        return embedUrl;
    }

    public String getCategory() {
        return category;
    }

    public String getLogo() {
        return logo;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }
}
