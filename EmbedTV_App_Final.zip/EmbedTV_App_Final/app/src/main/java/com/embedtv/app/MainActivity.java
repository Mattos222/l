package com.embedtv.app;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerViewCategories;
    private BottomNavigationView bottomNavigationView;
    private FrameLayout fragmentContainer;
    private List<Channel> allChannels;
    private Map<String, List<Channel>> channelsByCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar views
        recyclerViewCategories = findViewById(R.id.recyclerViewCategories);
        bottomNavigationView = findViewById(R.id.bottomNavigation);
        fragmentContainer = findViewById(R.id.fragmentContainer);

        // Carregar dados dos canais
        loadChannelsData();

        // Configurar RecyclerView para categorias
        setupCategoriesRecyclerView();

        // Configurar navegação inferior
        setupBottomNavigation();
    }

    private void loadChannelsData() {
        try {
            // Carregar arquivo JSON de canais dos assets
            String jsonString = loadJSONFromAsset("channels.json");
            Gson gson = new Gson();
            Type channelListType = new TypeToken<ArrayList<Channel>>(){}.getType();
            allChannels = gson.fromJson(jsonString, channelListType);

            // Organizar canais por categoria
            channelsByCategory = new HashMap<>();
            for (Channel channel : allChannels) {
                if (!channelsByCategory.containsKey(channel.getCategory())) {
                    channelsByCategory.put(channel.getCategory(), new ArrayList<>());
                }
                channelsByCategory.get(channel.getCategory()).add(channel);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String loadJSONFromAsset(String fileName) {
        String json;
        try {
            InputStream is = getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    private void setupCategoriesRecyclerView() {
        recyclerViewCategories.setLayoutManager(new LinearLayoutManager(this));
        List<CategoryWithChannels> categories = new ArrayList<>();
        
        for (Map.Entry<String, List<Channel>> entry : channelsByCategory.entrySet()) {
            categories.add(new CategoryWithChannels(entry.getKey(), entry.getValue()));
        }
        
        CategoriesAdapter adapter = new CategoriesAdapter(categories, channel -> {
            // Abrir tela de detalhes do canal quando um canal for clicado
            openChannelDetails(channel);
        });
        
        recyclerViewCategories.setAdapter(adapter);
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            
            if (itemId == R.id.nav_home) {
                // Mostrar tela inicial
                showHomeScreen();
                return true;
            } else if (itemId == R.id.nav_categories) {
                // Mostrar tela de categorias
                showCategoriesScreen();
                return true;
            } else if (itemId == R.id.nav_favorites) {
                // Mostrar tela de favoritos
                showFavoritesScreen();
                return true;
            } else if (itemId == R.id.nav_search) {
                // Mostrar tela de busca
                showSearchScreen();
                return true;
            }
            
            return false;
        });
        
        // Selecionar item inicial
        bottomNavigationView.setSelectedItemId(R.id.nav_home);
    }

    private void showHomeScreen() {
        // Implementar lógica para mostrar a tela inicial
        fragmentContainer.setVisibility(View.GONE);
        recyclerViewCategories.setVisibility(View.VISIBLE);
    }

    private void showCategoriesScreen() {
        // Implementar lógica para mostrar a tela de categorias
        recyclerViewCategories.setVisibility(View.GONE);
        fragmentContainer.setVisibility(View.VISIBLE);
        
        // Substituir o fragmento atual pelo fragmento de categorias
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, new CategoriesFragment())
                .commit();
    }

    private void showFavoritesScreen() {
        // Implementar lógica para mostrar a tela de favoritos
        recyclerViewCategories.setVisibility(View.GONE);
        fragmentContainer.setVisibility(View.VISIBLE);
        
        // Substituir o fragmento atual pelo fragmento de favoritos
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, new FavoritesFragment())
                .commit();
    }

    private void showSearchScreen() {
        // Implementar lógica para mostrar a tela de busca
        recyclerViewCategories.setVisibility(View.GONE);
        fragmentContainer.setVisibility(View.VISIBLE);
        
        // Substituir o fragmento atual pelo fragmento de busca
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, new SearchFragment())
                .commit();
    }

    private void openChannelDetails(Channel channel) {
        // Abrir a tela de detalhes do canal
        ChannelDetailsActivity.start(this, channel);
    }
}
