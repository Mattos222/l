package com.embedtv.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CategoryGridAdapter extends RecyclerView.Adapter<CategoryGridAdapter.CategoryViewHolder> {

    private List<String> categories;
    private OnCategoryClickListener listener;

    public interface OnCategoryClickListener {
        void onCategoryClick(String categoryName);
    }

    public CategoryGridAdapter(List<String> categories, OnCategoryClickListener listener) {
        this.categories = categories;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category_grid, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        String category = categories.get(position);
        holder.bind(category, listener);
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    static class CategoryViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivCategoryIcon;
        private TextView tvCategoryName;
        private TextView tvChannelCount;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCategoryIcon = itemView.findViewById(R.id.ivCategoryIcon);
            tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
            tvChannelCount = itemView.findViewById(R.id.tvChannelCount);
        }

        public void bind(String category, OnCategoryClickListener listener) {
            tvCategoryName.setText(category);
            
            // Definir ícone com base na categoria
            int iconResId = getCategoryIconResource(category);
            ivCategoryIcon.setImageResource(iconResId);
            
            // Em um app real, você contaria os canais em cada categoria
            // Para simplificar, vamos apenas mostrar um texto genérico
            tvChannelCount.setText("Vários canais");
            
            // Configurar clique no item
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onCategoryClick(category);
                }
            });
        }
        
        private int getCategoryIconResource(String category) {
            // Retornar ícone apropriado com base na categoria
            switch (category.toLowerCase()) {
                case "esportes":
                    return R.drawable.ic_category_sports;
                case "filmes e séries":
                    return R.drawable.ic_category_movies;
                case "documentários":
                    return R.drawable.ic_category_documentaries;
                case "infantil":
                    return R.drawable.ic_category_kids;
                case "notícias":
                    return R.drawable.ic_category_news;
                case "entretenimento":
                    return R.drawable.ic_category_entertainment;
                case "abertos":
                    return R.drawable.ic_category_broadcast;
                case "adulto":
                    return R.drawable.ic_category_adult;
                default:
                    return R.drawable.ic_category_default;
            }
        }
    }
}
