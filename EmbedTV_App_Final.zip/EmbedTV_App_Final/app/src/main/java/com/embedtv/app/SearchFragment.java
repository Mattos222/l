package com.embedtv.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends Fragment {

    private SearchView searchView;
    private RecyclerView recyclerViewResults;
    private List<Channel> allChannels;
    private ChannelAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);
        
        // Inicializar views
        searchView = view.findViewById(R.id.searchView);
        recyclerViewResults = view.findViewById(R.id.recyclerViewResults);
        
        // Carregar todos os canais
        loadAllChannels();
        
        // Configurar RecyclerView
        setupRecyclerView();
        
        // Configurar SearchView
        setupSearchView();
        
        return view;
    }

    private void loadAllChannels() {
        try {
            // Carregar arquivo JSON de canais dos assets
            String jsonString = loadJSONFromAsset("channels.json");
            Gson gson = new Gson();
            Type channelListType = new TypeToken<ArrayList<Channel>>(){}.getType();
            allChannels = gson.fromJson(jsonString, channelListType);
        } catch (Exception e) {
            e.printStackTrace();
            allChannels = new ArrayList<>();
        }
    }

    private String loadJSONFromAsset(String fileName) {
        String json;
        try {
            InputStream is = getActivity().getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    private void setupRecyclerView() {
        // Usar GridLayoutManager para exibir resultados em grade
        recyclerViewResults.setLayoutManager(new GridLayoutManager(getContext(), 3));
        
        // Inicialmente, não mostrar nenhum resultado
        adapter = new ChannelAdapter(new ArrayList<>(), channel -> {
            // Quando um canal for clicado, abrir seus detalhes
            ChannelDetailsActivity.start(getContext(), channel);
        });
        
        recyclerViewResults.setAdapter(adapter);
    }

    private void setupSearchView() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.length() >= 2) {
                    performSearch(newText);
                } else if (newText.isEmpty()) {
                    // Limpar resultados quando a busca estiver vazia
                    adapter.updateChannels(new ArrayList<>());
                }
                return true;
            }
        });
        
        // Expandir SearchView automaticamente
        searchView.setIconified(false);
        searchView.requestFocus();
    }

    private void performSearch(String query) {
        if (query == null || query.trim().isEmpty()) {
            adapter.updateChannels(new ArrayList<>());
            return;
        }
        
        // Converter para minúsculas para busca case-insensitive
        String lowerCaseQuery = query.toLowerCase();
        
        // Filtrar canais que correspondem à consulta
        List<Channel> results = new ArrayList<>();
        for (Channel channel : allChannels) {
            if (channel.getName().toLowerCase().contains(lowerCaseQuery) ||
                    channel.getCategory().toLowerCase().contains(lowerCaseQuery)) {
                results.add(channel);
            }
        }
        
        // Atualizar adapter com resultados
        adapter.updateChannels(results);
    }
}
