package com.embedtv.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class CategoriesAdapter extends RecyclerView.Adapter<CategoriesAdapter.CategoryViewHolder> {

    private List<CategoryWithChannels> categories;
    private OnChannelClickListener channelClickListener;

    public interface OnChannelClickListener {
        void onChannelClick(Channel channel);
    }

    public CategoriesAdapter(List<CategoryWithChannels> categories, OnChannelClickListener channelClickListener) {
        this.categories = categories;
        this.channelClickListener = channelClickListener;
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        CategoryWithChannels category = categories.get(position);
        holder.bind(category);
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    class CategoryViewHolder extends RecyclerView.ViewHolder {
        private TextView tvCategoryName;
        private RecyclerView recyclerViewChannels;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
            recyclerViewChannels = itemView.findViewById(R.id.recyclerViewChannels);
        }

        public void bind(CategoryWithChannels category) {
            tvCategoryName.setText(category.getCategoryName());
            
            // Configurar RecyclerView horizontal para os canais desta categoria
            recyclerViewChannels.setLayoutManager(
                    new LinearLayoutManager(itemView.getContext(), LinearLayoutManager.HORIZONTAL, false));
            
            ChannelsAdapter adapter = new ChannelsAdapter(
                    category.getChannels(), 
                    channelClickListener);
            
            recyclerViewChannels.setAdapter(adapter);
        }
    }

    // Adapter interno para os canais de cada categoria
    private static class ChannelsAdapter extends RecyclerView.Adapter<ChannelsAdapter.ChannelViewHolder> {

        private List<Channel> channels;
        private OnChannelClickListener listener;

        public ChannelsAdapter(List<Channel> channels, OnChannelClickListener listener) {
            this.channels = channels;
            this.listener = listener;
        }

        @NonNull
        @Override
        public ChannelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_channel, parent, false);
            return new ChannelViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ChannelViewHolder holder, int position) {
            Channel channel = channels.get(position);
            holder.bind(channel, listener);
        }

        @Override
        public int getItemCount() {
            return channels.size();
        }

        static class ChannelViewHolder extends RecyclerView.ViewHolder {
            private ImageView ivChannelLogo;
            private TextView tvChannelName;

            public ChannelViewHolder(@NonNull View itemView) {
                super(itemView);
                ivChannelLogo = itemView.findViewById(R.id.ivChannelLogo);
                tvChannelName = itemView.findViewById(R.id.tvChannelName);
            }

            public void bind(Channel channel, OnChannelClickListener listener) {
                tvChannelName.setText(channel.getName());
                
                // Carregar logo do canal usando Glide
                Context context = itemView.getContext();
                Glide.with(context)
                        .load("file:///android_asset/logos/" + channel.getLogo())
                        .placeholder(R.drawable.placeholder_channel)
                        .error(R.drawable.error_channel)
                        .into(ivChannelLogo);
                
                // Configurar clique no item
                itemView.setOnClickListener(v -> {
                    if (listener != null) {
                        listener.onChannelClick(channel);
                    }
                });
            }
        }
    }
}
