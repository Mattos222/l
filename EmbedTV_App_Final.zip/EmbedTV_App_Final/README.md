# EmbedTV App

Este é um aplicativo Android que permite assistir a canais de TV através de links embed do site embedtv.digital.

## Características

- Interface similar à Netflix
- Organização de canais por categorias
- Funcionalidade de busca
- Lista de favoritos
- Reprodução de vídeos em tela cheia
- Compatível com celulares e TVs Android

## Como compilar o APK

1. Abra o projeto no Android Studio
2. Sincronize o projeto com os arquivos Gradle
3. Vá para Build > Build Bundle(s) / APK(s) > Build APK(s)
4. O APK será gerado em app/build/outputs/apk/debug/app-debug.apk

## Como instalar o APK

1. Transfira o arquivo APK para seu dispositivo Android
2. No dispositivo, navegue até o arquivo APK e toque nele
3. Siga as instruções na tela para instalar o aplicativo
4. Se necessário, permita a instalação de aplicativos de fontes desconhecidas nas configurações do dispositivo

## Requisitos

- Android 5.0 (Lollipop) ou superior
- Conexão com a internet

## Solução de problemas

Se você encontrar problemas ao compilar o projeto:

1. Verifique se está usando a versão mais recente do Android Studio
2. Tente limpar e reconstruir o projeto (Build > Clean Project, seguido de Build > Rebuild Project)
3. Verifique se o Gradle está configurado corretamente
4. Certifique-se de que todas as dependências estão disponíveis

## Estrutura do Projeto

- `app/src/main/java/com/embedtv/app/` - Código-fonte Java
- `app/src/main/res/layout/` - Layouts XML
- `app/src/main/res/values/` - Recursos (cores, strings, estilos)
- `app/src/main/assets/` - Arquivos de dados (JSON de canais)
